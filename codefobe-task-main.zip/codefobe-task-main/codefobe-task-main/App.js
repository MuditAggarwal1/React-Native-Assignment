import React from 'react';

import Home from './src/screens/Home';


const App = () => {
  return (
    <Home />
  );
};

export default App;
